
#exe = 'galculator' # name of a program that can be launched several times, and is usually not running
#wmclass = 'galculator'  # its class
#desktop_file = 'fedora-galculator.desktop'  # its desktop file
exe = 'gnome-calculator' # name of a program that can be launched several times, and is usually not running
wmclass = 'gnome-calculator'  # its class
desktop_file = 'gcalctool.desktop'  # its desktop file

exe1 = 'gnome-session-properties'  # a program that doesn't have a launcher yet
wmclass1 = 'gnome-session-properties'  # its class
desktop_file1 = 'session-properties.desktop'  # its desktop-file

desktop_file2 = 'evince.desktop'  # another program that doesn't have a launcher yet
wmclass2 = 'evince'  # its class
desktop_file2 = 'evince.desktop'  # its desktop-file

